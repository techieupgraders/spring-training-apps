package com.demo.bean;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class EmployeeAddress 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int addressId;
	
	private String city;
	private String state;
	 
	public EmployeeAddress() {
		// TODO Auto-generated constructor stub
	}


	public EmployeeAddress(String city, String state) {
		super();
		this.city = city;
		this.state = state;
	}

	@Override
	public String toString() {
		return "EmployeeAddress [addressId=" + addressId + ", city=" + city + ", state=" + state + "]";
	}
	
	
	

}
