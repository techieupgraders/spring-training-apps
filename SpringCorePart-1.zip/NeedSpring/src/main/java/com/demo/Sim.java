package com.demo;

public interface Sim 
{
	void calling();
	void useInternet();

}
