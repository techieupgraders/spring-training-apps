package com.demo;

public class App
{
	public static void main(String[] args) {
		Sim airtel = new Airtel();
		airtel.calling();
		airtel.useInternet();
		
		Sim jio= new Jio();
		jio.calling();
		jio.useInternet();
		
		
		
	}
	

}
