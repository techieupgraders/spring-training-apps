package com.demo;

public class Airtel implements Sim
{
	public Airtel() {
		System.out.println("Airtel constructor");
	}
	
	@Override
	public void calling() {
		// TODO Auto-generated method stub
		System.out.println("Airtel calling()");
	}

	@Override
	public void useInternet() {
		// TODO Auto-generated method stub
		System.out.println("Airtel Use Internet()");
	}

	void display()
	{
		System.out.println("Display");
	}
}
