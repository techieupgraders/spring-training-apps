package com.demo.bean;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Component
@Entity
@Table(name = "spring_employee3")
public class Employee 
{
	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name = "Name")
	private String name;
	
	@Column(name = "Email")
	private String email;
	
	@OneToOne(cascade = CascadeType.ALL)
	private EmployeeAddress address;
	
	@ElementCollection
	private Map<String,String> impNums = new HashMap<>();
	
	public Employee() 
	{
		// TODO Auto-generated constructor stub
	}

	public void setEmail(String email) {
		String   regexPattern = "^(?=.{1,64}@)[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*@" 
				+ "[^-][A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$";

		Pattern pattern = Pattern.compile(regexPattern); 
		if( ! pattern.matcher(email).matches() || email==null || email.equals("")) 
		{
			this.email = null;			
		}
		else
		{
			this.email = email;
		}
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", email=" + email + ", address=" + address + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public EmployeeAddress getAddress() {
		return address;
	}

	public void setAddress(EmployeeAddress address) {
		this.address = address;
	}

	public Map<String, String> getImpNums() {
		return impNums;
	}

	public void setImpNums(Map<String, String> impNums) {
		this.impNums = impNums;
	}

	public String getEmail() {
		return email;
	}

	@PostConstruct
	public void initMethod()
	{
		System.out.println("init() lifecycle method ");
	}
	@PreDestroy
	public void destroyMethod()
	{
		System.out.println("destroyMethod() lifecycle method ");
	}
	
}
