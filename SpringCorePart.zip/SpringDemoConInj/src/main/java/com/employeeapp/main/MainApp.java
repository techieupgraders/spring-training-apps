package com.employeeapp.main;

import java.util.Scanner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.bean.Employee;
import com.employeeapp.database.DBUtil;

import jakarta.persistence.EntityManager;

public class MainApp 
{
	public static void main(String[] args)
	{
		int ans= 0 , id=0;
		Scanner sc= new Scanner(System.in);

		EntityManager manager = DBUtil.getManager();
		manager.getTransaction().begin(); 
		
		ApplicationContext context= new ClassPathXmlApplicationContext("config.xml");

		System.out.println("config read..");
		
		//Employee employee= context.getBean("e", Employee.class); //suggested way
		Employee employee= (Employee) context.getBean("e");
		
		
		manager.persist(employee);
		manager.getTransaction().commit(); 

		System.out.println(employee);
		System.out.println("all done !!");


	}


}
