package com.demo;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class App
{
	public static void main(String[] args) {
		//BeanFactory factory = new FileSystemXmlApplicationContext("C:\\Users\\sbramhan\\OneDrive - Capgemini\\Documents\\Batch Data 2023\\SCB_JavaMicroservice_Week1_11Dec to 15Dec-9amto6pm\\SCB-Week1\\NeedSpring2\\config.xml");
		//BeanFactory factory = new ClassPathXmlApplicationContext("config.xml");

		
		ApplicationContext factory = new ClassPathXmlApplicationContext("config.xml");

		
		Sim sim = factory.getBean("sim", Sim.class);
		
		sim.calling();
		sim.useInternet();
		System.out.println("main ends.." +sim.getClass().getName());
	}
	

}
