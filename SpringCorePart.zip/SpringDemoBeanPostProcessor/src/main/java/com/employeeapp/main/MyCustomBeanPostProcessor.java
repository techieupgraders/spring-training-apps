package com.employeeapp.main;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

import com.demo.bean.Employee;

public class MyCustomBeanPostProcessor implements BeanPostProcessor
{
	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		System.out.println("postProcessAfterInitialization called for "+beanName);
		return bean;

	}

	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		System.out.println("postProcessBeforeInitialization called for "+beanName);		
		return bean;
	}

}
