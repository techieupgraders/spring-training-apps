package com.employeeapp.main;

import java.util.Scanner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.bean.Employee;
import com.employeeapp.database.DBUtil;

import jakarta.persistence.EntityManager;

public class MainApp 
{
	public static void main(String[] args)
	{
		int ans= 0 , id=0;
		Scanner sc= new Scanner(System.in);

		EntityManager manager = DBUtil.getManager();
		manager.getTransaction().begin(); 
		//ApplicationContext context= new ClassPathXmlApplicationContext("config.xml");
		AbstractApplicationContext context= new ClassPathXmlApplicationContext("config.xml");

		System.out.println("config read..");
		
		//Employee employee= context.getBean("e", Employee.class); //suggested way
		Employee employee1= (Employee) context.getBean("e");
		Employee employee2= (Employee) context.getBean("e");

		
	//	manager.persist(employee);
		manager.getTransaction().commit(); 

		System.out.println(employee1.hashCode());
		System.out.println(employee2.hashCode());
		System.out.println(employee1.equals(employee2));
		System.out.println("all done !!");
		
		context.registerShutdownHook();

		

	}


}
