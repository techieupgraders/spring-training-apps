package com.demo.bean;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
//@ComponentScan(basePackages = "com.demo.bean")
public class AppConfig 
{
	@Bean
	@Scope("singleton")
	public Employee getEmployee()
	{
		return new Employee();
	}
	
	@Bean
	
	public EmployeeAddress getEmployeeAddress()
	{
		return new EmployeeAddress();
	}


}
