package com.employeeapp.main;

import java.util.Scanner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.bean.AppConfig;
import com.demo.bean.Employee;
import com.demo.bean.EmployeeAddress;
import com.employeeapp.database.DBUtil;

import jakarta.persistence.EntityManager;

public class MainApp 
{
	public static void main(String[] args)
	{
		int ans= 0 , id=0;
		Scanner sc= new Scanner(System.in);

		EntityManager manager = DBUtil.getManager();
		manager.getTransaction().begin(); 

		//java-based way 
		AnnotationConfigApplicationContext context= new AnnotationConfigApplicationContext(AppConfig.class);

		System.out.println("config read..");

		EmployeeAddress address = context.getBean(EmployeeAddress.class);
		Employee employee1= (Employee) context.getBean(Employee.class);

		employee1.setAddress(address);

		System.out.println(employee1.hashCode());
		
		EmployeeAddress address1 = context.getBean(EmployeeAddress.class);
		Employee employee11= (Employee) context.getBean(Employee.class);

		employee11.setAddress(address1);

		System.out.println(employee11.hashCode());
		System.out.println("all done !!");

		context.registerShutdownHook();



	}


}
