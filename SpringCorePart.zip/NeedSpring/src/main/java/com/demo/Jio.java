package com.demo;

public class Jio implements Sim
{

	@Override
	public void calling() {
		// TODO Auto-generated method stub
		System.out.println("Jio calling()");
	}

	@Override
	public void useInternet() {
		// TODO Auto-generated method stub
		System.out.println("Jio Use Internet()");
	}

}
