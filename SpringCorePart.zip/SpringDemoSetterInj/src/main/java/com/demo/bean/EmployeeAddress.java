package com.demo.bean;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "EmployeeAddress3") 
public class EmployeeAddress 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int addressId;

	private String city;
	private String state;

	public EmployeeAddress() {
		// TODO Auto-generated constructor stub
	}
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "EmployeeAddress [addressId=" + addressId + ", city=" + city + ", state=" + state + "]";
	}




}
