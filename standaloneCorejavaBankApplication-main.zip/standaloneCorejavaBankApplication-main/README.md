Create Bank server app with following functionality.
Show Balance
Withdraw Money
Deposit Money
Transfer Funds (from one account to another)
Display Last 10 Transactions



Date Transaction ID Amount Cr/Dr Available Balance Description
11/08 12345 500 CR 500 New Account
12/08 123568 100 CR 600 Deposit
12/08 123467890 50 DR 550 Withdraw
Use validations wherever applicable. e.g. balance of an account cannot go below zero.
Consider following points….
1. A customer has only one account and one account belongs to one customer.
2. There is only one type of account available in the bank at this moment, you may call this as
savings account.
3. Since this app is going to run on a server, input and output statements should be written only in
the Main file. No other file/module should contain input/output statements.
